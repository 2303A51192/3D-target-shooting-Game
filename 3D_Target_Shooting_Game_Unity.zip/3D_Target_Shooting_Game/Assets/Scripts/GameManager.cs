using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum GameState { Playing, Paused, GameOver }

/// <summary>Controls the round: arrows left, pause, restart and game over.</summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public int totalArrows = 10;
    public int winScore = 60;
    public ScoreManager scoreManager;
    public UIManager uiManager;

    public GameState State { get; private set; }
    public int ArrowsLeft { get; private set; }

    int arrowsInFlight;
    bool endQueued;

    void Awake()
    {
        Instance = this;
        Time.timeScale = 1f;
        QualitySettings.shadowDistance = 120f;
        if (scoreManager == null) scoreManager = GetComponent<ScoreManager>();
    }

    void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    void Start()
    {
        StartRound();
    }

    void StartRound()
    {
        Time.timeScale = 1f;
        ArrowsLeft = totalArrows;
        arrowsInFlight = 0;
        endQueued = false;
        State = GameState.Playing;

        scoreManager.ResetScore();
        uiManager.ShowPlaying();
        uiManager.UpdateScore(0);
        uiManager.UpdateArrows(ArrowsLeft, totalArrows);
        SetCursorLocked(true);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R)) RestartGame();
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P)) TogglePause();
    }

    public void ArrowFired()
    {
        ArrowsLeft--;
        arrowsInFlight++;
        uiManager.UpdateArrows(ArrowsLeft, totalArrows);
    }

    /// <summary>Called once by every arrow when it lands. points = 0 means a miss.</summary>
    public void ArrowResolved(int points, TargetController target)
    {
        arrowsInFlight = Mathf.Max(0, arrowsInFlight - 1);
        if (State == GameState.GameOver) return;

        scoreManager.AddScore(points);
        uiManager.UpdateScore(scoreManager.Score);
        uiManager.ShowHitMessage(points);
        if (target != null && points > 0) target.PlayHitEffect();

        if (ArrowsLeft <= 0 && arrowsInFlight <= 0 && !endQueued)
        {
            endQueued = true;
            StartCoroutine(EndRoutine());
        }
    }

    IEnumerator EndRoutine()
    {
        yield return new WaitForSeconds(1.5f);
        EndGame();
    }

    void EndGame()
    {
        State = GameState.GameOver;
        bool newRecord = scoreManager.SaveHighScore();

        string message;
        if (scoreManager.Score >= winScore) message = "YOU WIN! Master Archer!";
        else if (scoreManager.Score >= 30) message = "Nice shooting! Try for " + winScore + "+ to win.";
        else message = "Keep practising - aim a little higher at far targets!";

        uiManager.ShowGameOver(scoreManager.Score, scoreManager.HighScore, message, newRecord);
        SetCursorLocked(false);
    }

    public void TogglePause()
    {
        if (State == GameState.Playing)
        {
            State = GameState.Paused;
            Time.timeScale = 0f;
            uiManager.ShowPause(true);
            SetCursorLocked(false);
        }
        else if (State == GameState.Paused)
        {
            State = GameState.Playing;
            Time.timeScale = 1f;
            uiManager.ShowPause(false);
            SetCursorLocked(true);
        }
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void GoToMainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }

    static void SetCursorLocked(bool locked)
    {
        Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible = !locked;
    }
}

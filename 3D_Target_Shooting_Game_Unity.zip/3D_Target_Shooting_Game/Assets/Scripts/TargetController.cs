using System.Collections;
using UnityEngine;

/// <summary>
/// Lives on the Target prefab. Works out which ring was hit from the hit position,
/// so one arrow can only ever give one score.
/// </summary>
public class TargetController : MonoBehaviour
{
    public const float TargetRadius = 1.2f;                                   // metres
    public static readonly float[] RingFractions = { 0.2f, 0.4f, 0.6f, 0.8f, 1.0f }; // yellow, red, blue, black, white
    public static readonly int[] RingPoints = { 10, 8, 6, 4, 2 };

    Quaternion baseRotation;
    Coroutine wobbleRoutine;

    void Awake()
    {
        baseRotation = transform.rotation;
    }

    /// <summary>Returns the points for a world-space hit position (0 if outside the rings).</summary>
    public int GetScore(Vector3 worldPoint)
    {
        Vector3 local = transform.InverseTransformPoint(worldPoint);
        float distance = new Vector2(local.x, local.y).magnitude / TargetRadius;
        for (int i = 0; i < RingFractions.Length; i++)
        {
            if (distance <= RingFractions[i]) return RingPoints[i];
        }
        return 0;
    }

    public void PlayHitEffect()
    {
        if (wobbleRoutine != null) StopCoroutine(wobbleRoutine);
        wobbleRoutine = StartCoroutine(Wobble());
    }

    IEnumerator Wobble()
    {
        const float duration = 0.6f;
        float t = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            float angle = Mathf.Sin(t * 40f) * (1f - t / duration) * 3f;
            transform.rotation = baseRotation * Quaternion.Euler(angle, 0f, 0f);
            yield return null;
        }
        transform.rotation = baseRotation;
    }

    public static string RingName(int points)
    {
        switch (points)
        {
            case 10: return "BULLSEYE!";
            case 8: return "Red ring";
            case 6: return "Blue ring";
            case 4: return "Black ring";
            case 2: return "White ring";
            default: return "Miss";
        }
    }
}

using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Updates the in-game HUD, pause screen and game over screen.</summary>
public class UIManager : MonoBehaviour
{
    [Header("HUD")]
    public Text scoreText;
    public Text arrowsText;
    public Text hitText;

    [Header("Panels")]
    public GameObject hudPanel;
    public GameObject pausePanel;
    public GameObject gameOverPanel;

    [Header("Game Over")]
    public Text finalScoreText;
    public Text resultText;
    public Text highScoreText;

    [Header("Buttons")]
    public Button resumeButton;
    public Button pauseRestartButton;
    public Button pauseMenuButton;
    public Button overRestartButton;
    public Button overMenuButton;

    Coroutine hitRoutine;

    void Awake()
    {
        if (resumeButton != null) resumeButton.onClick.AddListener(() => GameManager.Instance.TogglePause());
        if (pauseRestartButton != null) pauseRestartButton.onClick.AddListener(() => GameManager.Instance.RestartGame());
        if (overRestartButton != null) overRestartButton.onClick.AddListener(() => GameManager.Instance.RestartGame());
        if (pauseMenuButton != null) pauseMenuButton.onClick.AddListener(() => GameManager.Instance.GoToMainMenu());
        if (overMenuButton != null) overMenuButton.onClick.AddListener(() => GameManager.Instance.GoToMainMenu());
    }

    public void ShowPlaying()
    {
        hudPanel.SetActive(true);
        pausePanel.SetActive(false);
        gameOverPanel.SetActive(false);
        hitText.text = "";
    }

    public void ShowPause(bool show)
    {
        pausePanel.SetActive(show);
    }

    public void UpdateScore(int score)
    {
        scoreText.text = "Score: " + score;
    }

    public void UpdateArrows(int left, int total)
    {
        arrowsText.text = "Arrows: " + left + " / " + total;
    }

    public void ShowHitMessage(int points)
    {
        Color color;
        switch (points)
        {
            case 10: color = new Color(1f, 0.85f, 0.1f); break;
            case 8: color = new Color(1f, 0.3f, 0.25f); break;
            case 6: color = new Color(0.35f, 0.7f, 1f); break;
            case 4: color = new Color(0.75f, 0.75f, 0.75f); break;
            case 2: color = Color.white; break;
            default: color = new Color(0.8f, 0.8f, 0.8f); break;
        }
        string message = points > 0 ? "+" + points + "  " + TargetController.RingName(points) : "Miss";

        if (hitRoutine != null) StopCoroutine(hitRoutine);
        hitRoutine = StartCoroutine(FadeHitText(message, color));
    }

    IEnumerator FadeHitText(string message, Color color)
    {
        hitText.text = message;
        float t = 0f;
        const float duration = 1.6f;
        while (t < duration)
        {
            t += Time.unscaledDeltaTime;
            color.a = 1f - Mathf.Clamp01((t - 0.8f) / (duration - 0.8f));
            hitText.color = color;
            yield return null;
        }
        hitText.text = "";
    }

    public void ShowGameOver(int score, int highScore, string message, bool newRecord)
    {
        hudPanel.SetActive(false);
        pausePanel.SetActive(false);
        gameOverPanel.SetActive(true);
        finalScoreText.text = "Final Score: " + score;
        resultText.text = message;
        highScoreText.text = newRecord ? "NEW HIGH SCORE!" : "Best: " + highScore;
    }
}

using UnityEngine;

/// <summary>First-person mouse aiming. Hold the right mouse button to zoom.</summary>
public class PlayerController : MonoBehaviour
{
    public Transform cameraTransform;
    public float sensitivity = 2f;
    public float maxYaw = 70f;
    public float minPitch = -25f;
    public float maxPitch = 35f;
    public float zoomFov = 28f;

    Camera cam;
    float defaultFov;
    float yaw;
    float pitch;

    void Start()
    {
        if (cameraTransform != null)
        {
            cam = cameraTransform.GetComponent<Camera>();
            if (cam != null) defaultFov = cam.fieldOfView;
        }
    }

    void Update()
    {
        if (cameraTransform == null) return;
        if (GameManager.Instance == null || GameManager.Instance.State != GameState.Playing) return;

        float fovScale = 1f;
        if (cam != null)
        {
            float target = Input.GetMouseButton(1) ? zoomFov : defaultFov;
            cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, target, Time.deltaTime * 10f);
            fovScale = cam.fieldOfView / defaultFov; // slower aiming while zoomed
        }

        yaw += Input.GetAxis("Mouse X") * sensitivity * fovScale;
        pitch -= Input.GetAxis("Mouse Y") * sensitivity * fovScale;
        yaw = Mathf.Clamp(yaw, -maxYaw, maxYaw);
        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

        transform.localRotation = Quaternion.Euler(0f, yaw, 0f);
        cameraTransform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }
}

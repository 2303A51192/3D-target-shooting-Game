using System.Collections;
using UnityEngine;

/// <summary>Shoots arrows on left click and plays the bow animation.</summary>
public class BowController : MonoBehaviour
{
    public GameObject arrowPrefab;
    public float arrowSpeed = 70f;
    [Tooltip("Aim slightly upward to make up for arrow drop at medium range.")]
    public float aimCompensationDegrees = 1.5f;
    public float reloadTime = 0.8f;

    Transform cam;
    Transform heldArrow;
    Vector3 bowRestPosition;
    Vector3 heldArrowRest;
    bool reloading;

    void Start()
    {
        Camera c = GetComponentInParent<Camera>();
        if (c == null) c = Camera.main;
        if (c != null) cam = c.transform;

        heldArrow = transform.Find("HeldArrow");
        bowRestPosition = transform.localPosition;
        if (heldArrow != null) heldArrowRest = heldArrow.localPosition;
    }

    void Update()
    {
        if (cam == null || arrowPrefab == null) return;
        GameManager gm = GameManager.Instance;
        if (gm == null || gm.State != GameState.Playing) return;

        if (Input.GetMouseButtonDown(0) && !reloading && gm.ArrowsLeft > 0)
        {
            Shoot(gm);
        }
    }

    void Shoot(GameManager gm)
    {
        gm.ArrowFired();

        Vector3 direction = Quaternion.AngleAxis(-aimCompensationDegrees, cam.right) * cam.forward;
        Vector3 position = cam.position + cam.forward * 0.8f - cam.up * 0.05f;

        GameObject arrow = Instantiate(arrowPrefab, position, Quaternion.LookRotation(direction));
        ArrowController controller = arrow.GetComponent<ArrowController>();
        if (controller != null) controller.Launch(direction, arrowSpeed);

        if (AudioManager.Instance != null) AudioManager.Instance.PlayShot();
        StartCoroutine(ShootAnimation(gm));
    }

    IEnumerator ShootAnimation(GameManager gm)
    {
        reloading = true;
        if (heldArrow != null) heldArrow.gameObject.SetActive(false);

        // Bow kicks back, then settles.
        const float kickTime = 0.15f;
        float t = 0f;
        while (t < kickTime)
        {
            t += Time.deltaTime;
            float k = 1f - Mathf.Clamp01(t / kickTime);
            transform.localPosition = bowRestPosition + new Vector3(0f, 0.02f, -0.06f) * k;
            yield return null;
        }
        transform.localPosition = bowRestPosition;

        yield return new WaitForSeconds(reloadTime);

        // A new arrow slides onto the string.
        if (heldArrow != null && gm.ArrowsLeft > 0)
        {
            heldArrow.gameObject.SetActive(true);
            const float drawTime = 0.25f;
            t = 0f;
            while (t < drawTime)
            {
                t += Time.deltaTime;
                float k = 1f - Mathf.Clamp01(t / drawTime);
                heldArrow.localPosition = heldArrowRest + new Vector3(0f, 0f, 0.5f) * k;
                yield return null;
            }
            heldArrow.localPosition = heldArrowRest;
        }
        reloading = false;
    }
}

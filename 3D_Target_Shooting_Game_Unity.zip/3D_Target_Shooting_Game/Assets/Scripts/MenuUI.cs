using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>Main menu buttons and the instructions panel.</summary>
public class MenuUI : MonoBehaviour
{
    public Button startButton;
    public Button instructionsButton;
    public Button quitButton;
    public Button backButton;
    public GameObject mainPanel;
    public GameObject instructionsPanel;
    public Text highScoreText;
    public Transform swayingTarget;

    Quaternion targetBase;

    void Awake()
    {
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (startButton != null) startButton.onClick.AddListener(StartGame);
        if (instructionsButton != null) instructionsButton.onClick.AddListener(() => ShowInstructions(true));
        if (backButton != null) backButton.onClick.AddListener(() => ShowInstructions(false));
        if (quitButton != null) quitButton.onClick.AddListener(QuitGame);
        if (swayingTarget != null) targetBase = swayingTarget.rotation;
    }

    void Start()
    {
        ShowInstructions(false);
        if (highScoreText != null)
        {
            highScoreText.text = "Best Score: " + PlayerPrefs.GetInt(ScoreManager.HighScoreKey, 0);
        }
    }

    void Update()
    {
        if (swayingTarget != null)
        {
            swayingTarget.rotation = targetBase * Quaternion.Euler(0f, Mathf.Sin(Time.time * 0.8f) * 25f, 0f);
        }
    }

    void ShowInstructions(bool show)
    {
        if (instructionsPanel != null) instructionsPanel.SetActive(show);
        if (mainPanel != null) mainPanel.SetActive(!show);
    }

    public void StartGame()
    {
        SceneManager.LoadScene("GameScene");
    }

    public void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}

using UnityEngine;

/// <summary>
/// Plays the bow, impact and music sounds. No audio files are required:
/// simple sounds are generated in code. To use your own, drag clips into the
/// public fields below (or just leave them empty).
/// </summary>
public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    public AudioClip shootClip;
    public AudioClip impactClip;
    public AudioClip musicClip;
    [Range(0f, 1f)] public float sfxVolume = 0.8f;
    [Range(0f, 1f)] public float musicVolume = 0.22f;

    const int SampleRate = 44100;
    AudioSource sfxSource;
    AudioSource musicSource;

    void Awake()
    {
        Instance = this;

        sfxSource = gameObject.AddComponent<AudioSource>();
        sfxSource.playOnAwake = false;
        sfxSource.spatialBlend = 0f;

        musicSource = gameObject.AddComponent<AudioSource>();
        musicSource.playOnAwake = false;
        musicSource.spatialBlend = 0f;
        musicSource.loop = true;
        musicSource.volume = musicVolume;

        if (shootClip == null) shootClip = MakeShotClip();
        if (impactClip == null) impactClip = MakeImpactClip();
        if (musicClip == null) musicClip = MakeMusicClip();

        musicSource.clip = musicClip;
        musicSource.Play();
    }

    void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    public void PlayShot()
    {
        if (shootClip != null) sfxSource.PlayOneShot(shootClip, sfxVolume);
    }

    public void PlayImpact()
    {
        if (impactClip != null) sfxSource.PlayOneShot(impactClip, sfxVolume);
    }

    // ---------- procedural sounds ----------

    static AudioClip MakeClip(string clipName, float seconds, System.Func<float, float> generator)
    {
        int count = Mathf.CeilToInt(seconds * SampleRate);
        float[] data = new float[count];
        for (int i = 0; i < count; i++)
        {
            data[i] = Mathf.Clamp(generator(i / (float)SampleRate), -1f, 1f);
        }
        AudioClip clip = AudioClip.Create(clipName, count, 1, SampleRate, false);
        clip.SetData(data, 0);
        return clip;
    }

    static AudioClip MakeShotClip()
    {
        System.Random rng = new System.Random(1);
        float lowpass = 0f;
        return MakeClip("BowShot", 0.4f, t =>
        {
            float noise = (float)(rng.NextDouble() * 2.0 - 1.0);
            lowpass += 0.15f * (noise - lowpass);
            float whoosh = lowpass * Mathf.Exp(-t * 14f) * 2f;
            float twang = Mathf.Sin(2f * Mathf.PI * 160f * t) * Mathf.Exp(-t * 9f) * 0.45f
                        + Mathf.Sin(2f * Mathf.PI * 320f * t) * Mathf.Exp(-t * 13f) * 0.2f;
            return (whoosh + twang) * 0.9f;
        });
    }

    static AudioClip MakeImpactClip()
    {
        System.Random rng = new System.Random(2);
        return MakeClip("ArrowImpact", 0.3f, t =>
        {
            float noise = (float)(rng.NextDouble() * 2.0 - 1.0);
            float thud = Mathf.Sin(2f * Mathf.PI * 85f * t) * Mathf.Exp(-t * 22f) * 0.8f;
            return thud + noise * Mathf.Exp(-t * 70f) * 0.5f;
        });
    }

    static AudioClip MakeMusicClip()
    {
        float[] melody =
        {
            261.63f, 329.63f, 392.00f, 523.25f, 392.00f, 329.63f, 293.66f, 392.00f,
            349.23f, 440.00f, 523.25f, 440.00f, 349.23f, 293.66f, 261.63f, 329.63f
        };
        float[] bass = { 130.81f, 110.00f, 87.31f, 98.00f };
        const float noteLength = 0.75f;  // 16 notes = 12 seconds
        const float bassLength = 3f;     // 4 bass notes = 12 seconds

        return MakeClip("Music", 12f, t =>
        {
            int noteIndex = Mathf.Min((int)(t / noteLength), melody.Length - 1);
            float local = t - noteIndex * noteLength;
            float env = Mathf.Min(local / 0.05f, 1f) * Mathf.Exp(-local * 2.2f)
                        * Mathf.Clamp01((noteLength - local) / 0.05f);
            float note = Mathf.Sin(2f * Mathf.PI * melody[noteIndex] * t) * env * 0.28f;

            int bassIndex = Mathf.Min((int)(t / bassLength), bass.Length - 1);
            float bassLocal = t - bassIndex * bassLength;
            float bassEnv = Mathf.Sin(Mathf.PI * bassLocal / bassLength);
            float low = Mathf.Sin(2f * Mathf.PI * bass[bassIndex] * t) * bassEnv * 0.18f;

            return note + low;
        });
    }
}
